"""
Gemini AI Client with strict Rate Limiting, 503 High-Demand Auto-Failover,
404 Elimination, Error Visibility, and Config Window Redaction.
"""

import os
import time
import json
import random
import threading
import urllib.request
import urllib.error
from config import ACTIVE_MODELS, DEFAULT_MODEL, CREATIVE_NAMES, DEFAULT_REQUEST_COOLDOWN

# Optional imports
try:
    from PIL import Image, ImageDraw, ImageGrab
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    from google import genai
    GENAI_SDK_AVAILABLE = True
except ImportError:
    GENAI_SDK_AVAILABLE = False


class RateLimiter:
    """Thread-safe request rate limiter to prevent flooding the API key."""
    def __init__(self, cooldown=DEFAULT_REQUEST_COOLDOWN):
        self.cooldown = cooldown
        self.last_request_time = 0.0
        self.lock = threading.Lock()

    def acquire(self):
        with self.lock:
            now = time.time()
            elapsed = now - self.last_request_time
            if elapsed < self.cooldown:
                sleep_needed = self.cooldown - elapsed
                time.sleep(sleep_needed)
            self.last_request_time = time.time()


class GeminiEngine:
    def __init__(self, api_key="", model_name=DEFAULT_MODEL, cooldown=DEFAULT_REQUEST_COOLDOWN):
        self.api_key = api_key.strip().strip('"').strip("'")
        self.model_name = model_name
        self.rate_limiter = RateLimiter(cooldown)
        self.last_error_details = ""

    def set_cooldown(self, cooldown):
        self.rate_limiter.cooldown = max(0.5, float(cooldown))

    def get_api_key(self):
        raw = self.api_key or os.environ.get("GEMINI_API_KEY", "")
        return raw.strip().strip('"').strip("'")

    def discover_models(self):
        """Discovers models that actually exist and support generateContent for this API key."""
        key = self.get_api_key()
        if not key:
            return ACTIVE_MODELS, "No API key configured. Enter your key in Settings."

        self.rate_limiter.acquire()
        url = f"https://generativelanguage.googleapis.com/v1beta/models?key={key}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "GeminiCursorSwarm/2.2"})
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                models = []
                for m in data.get("models", []):
                    name = m.get("name", "").replace("models/", "")
                    methods = m.get("supportedGenerationMethods", [])
                    if "generateContent" in methods:
                        models.append(name)

                # Prioritize reliable flash models
                flash_models = [m for m in models if "1.5-flash" in m] + [m for m in models if "flash" in m and "1.5-flash" not in m]
                other_models = [m for m in models if "flash" not in m]
                sorted_models = flash_models + other_models

                if sorted_models:
                    return sorted_models, None
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            return ACTIVE_MODELS, f"HTTP Error {e.code}: {err_body}"
        except Exception as e:
            return ACTIVE_MODELS, str(e)

        return ACTIVE_MODELS, None

    def call_gemini_raw(self, prompt, system_instruction=None):
        """
        Executes generateContent with:
        1. Thread-safe rate limiting (no spamming the key)
        2. Automatic 503 High Demand recovery (switches to non-busy model)
        3. Automatic 404 / 429 recovery (cascades through candidate models)
        4. Visible detailed error reporting (never fails silently!)
        """
        api_key = self.get_api_key()
        if not api_key:
            err = "No GEMINI_API_KEY provided. Please enter your API Key in the Settings tab."
            self.last_error_details = err
            return None, err

        # Candidate models ordered with current model first, then remaining active models
        models_to_try = [self.model_name] + [m for m in ACTIVE_MODELS if m != self.model_name]
        attempted_errors = []

        for candidate_model in models_to_try:
            print(f"[GeminiEngine] Attempting model: {candidate_model}...")
            self.rate_limiter.acquire()

            # 1. Try REST API as primary robust path (handles exact error codes and failover)
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{candidate_model}:generateContent?key={api_key}"
            payload = {
                "contents": [{"parts": [{"text": prompt}]}]
            }
            if system_instruction:
                payload["systemInstruction"] = {"parts": [{"text": system_instruction}]}

            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={
                        "Content-Type": "application/json",
                        "User-Agent": "GeminiCursorSwarm/2.2"
                    },
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=18) as resp:
                    res_json = json.loads(resp.read().decode("utf-8"))
                    candidates = res_json.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        if parts:
                            text = parts[0].get("text", "").strip()
                            if text:
                                if candidate_model != self.model_name:
                                    print(f"[GeminiEngine] Auto-switched working model to: {candidate_model}")
                                    self.model_name = candidate_model
                                self.last_error_details = ""
                                return text, None

            except urllib.error.HTTPError as e:
                err_body = e.read().decode("utf-8", errors="ignore")
                parsed_msg = ""
                try:
                    err_json = json.loads(err_body)
                    parsed_msg = err_json.get("error", {}).get("message", "")
                except Exception:
                    parsed_msg = err_body[:200]

                err_summary = f"{candidate_model} (HTTP {e.code}): {parsed_msg or 'Server error'}"
                attempted_errors.append(err_summary)
                print(f"[GeminiEngine] {err_summary}")

                # 503 High Demand or 404 Not Found or 429 Rate Limit -> Try next candidate model
                if e.code in [503, 404, 429]:
                    time.sleep(1.0)
                    continue

                # 400 Bad Request (e.g. invalid key) -> Don't loop endlessly on bad key
                if "API key not valid" in err_body or "API_KEY_INVALID" in err_body:
                    msg = "Google reported: Invalid API key. Please check your key in Settings."
                    self.last_error_details = msg
                    return None, msg

            except Exception as e:
                err_summary = f"{candidate_model} (Connection error): {str(e)}"
                attempted_errors.append(err_summary)
                print(f"[GeminiEngine] {err_summary}")
                continue

            # 2. Try SDK as secondary fallback if REST failed for non-HTTP reasons
            if GENAI_SDK_AVAILABLE:
                try:
                    client = genai.Client(api_key=api_key)
                    config = {}
                    if system_instruction:
                        config["system_instruction"] = system_instruction
                    response = client.models.generate_content(
                        model=candidate_model,
                        contents=prompt,
                        config=config if config else None
                    )
                    text = (response.text or "").strip()
                    if text:
                        if candidate_model != self.model_name:
                            self.model_name = candidate_model
                        self.last_error_details = ""
                        return text, None
                except Exception as e:
                    attempted_errors.append(f"{candidate_model} (SDK): {str(e)}")

        full_error = " | ".join(attempted_errors) if attempted_errors else "All models failed to respond."
        self.last_error_details = full_error
        return None, full_error

    def choose_unique_name(self, existing_names):
        """Asks Gemini AI to choose a unique 1-word name not currently in use."""
        existing_str = ", ".join(f"'{n}'" for n in existing_names) if existing_names else "none"
        prompt = (
            f"You are a new autonomous desktop AI cursor entity. "
            f"Pick a single, creative, distinct 1-word futuristic or mythological name for yourself. "
            f"CRITICAL CONSTRAINT: You CANNOT pick any name already in use: [{existing_str}]. "
            f"Respond ONLY with the single chosen name, exactly 1 word, no punctuation, no explanations."
        )
        sys_inst = "Output only the single chosen 1-word name."
        res, err = self.call_gemini_raw(prompt, sys_inst)
        if res:
            clean = "".join(c for c in res if c.isalnum()).strip().capitalize()
            if clean and clean.lower() not in [n.lower() for n in existing_names]:
                return clean

        # Safe fallback
        avail = [n for n in CREATIVE_NAMES if n.lower() not in [x.lower() for x in existing_names]]
        if avail:
            return random.choice(avail)
        return f"Gemini_{random.randint(100, 999)}"

    def mask_and_capture_screen(self, config_window_bbox):
        """Captures screen and STRICTLY REDACTS/BLACKS OUT the config/chat window."""
        if not PIL_AVAILABLE:
            return None
        try:
            screenshot = ImageGrab.grab()
            draw = ImageDraw.Draw(screenshot)
            if config_window_bbox:
                x, y, w, h = config_window_bbox
                x1, y1 = max(0, x - 5), max(0, y - 5)
                x2, y2 = min(screenshot.width, x + w + 5), min(screenshot.height, y + h + 5)
                # Blackout redaction shield
                draw.rectangle([x1, y1, x2, y2], fill="#000000", outline="#ef4444", width=3)
                draw.text(
                    (x1 + 15, y1 + 15),
                    "[REDACTED: CONFIG/CHAT WINDOW - GEMINI VISION BLOCKED]",
                    fill="#ef4444"
                )
            return screenshot
        except Exception as e:
            print(f"[Vision] Capture exception: {e}")
            return None
