#!/usr/bin/env python3
"""
================================================================================
GEMINI CURSOR SWARM - MASTER RUNNER (run.py)
================================================================================
Usage:
    python run.py

Requirements:
    pip install -r requirements.txt
================================================================================
"""

import sys

# Tkinter verification
try:
    import tkinter as tk
except ImportError:
    print("\n" + "=" * 70)
    print(" [GEMINI CURSOR SWARM] - MISSING TKINTER DEPENDENCY")
    print("=" * 70)
    print("Tkinter is required to render the desktop GUI and floating cursors.")
    print(" • Windows & macOS: Tkinter is included by default with Python.")
    print(" • Linux (Ubuntu/Debian): sudo apt-get install python3-tk")
    print(" • Linux (Fedora/RHEL):   sudo dnf install python3-tkinter")
    print(" • Linux (Arch):          sudo pacman -S tk")
    print("=" * 70 + "\n")
    sys.exit(1)

from controller_window import GeminiSwarmApp


def main():
    root = tk.Tk()
    app = GeminiSwarmApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
