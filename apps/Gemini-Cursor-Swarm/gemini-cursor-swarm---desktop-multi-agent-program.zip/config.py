"""
Configuration constants and defaults for Gemini Cursor Swarm.
"""

import os

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gemini_swarm_data.json")

# Verified active models with gemini-1.5-flash first to avoid 503 High Demand spikes
ACTIVE_MODELS = [
    "gemini-1.5-flash",
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-flash-latest",
    "gemini-1.5-pro",
]

DEFAULT_MODEL = "gemini-1.5-flash"

# Rate limiting / anti-spam defaults to prevent HTTP 503 / 429
DEFAULT_REQUEST_COOLDOWN = 2.0  # Minimum seconds between API requests
MAX_RETRIES_PER_MODEL = 2       # Retries with exponential backoff before model failover

DISTINCT_COLORS = [
    "#06b6d4",  # Cyan
    "#10b981",  # Emerald
    "#a855f7",  # Purple
    "#f43f5e",  # Rose
    "#f59e0b",  # Amber
    "#ec4899",  # Pink
    "#6366f1",  # Indigo
    "#14b8a6",  # Teal
    "#eab308",  # Yellow
    "#8b5cf6",  # Violet
    "#3b82f6",  # Blue
    "#84cc16",  # Lime
]

CREATIVE_NAMES = [
    "Aura", "Cipher", "Zephyr", "Nova", "Helios", "Echo", "Vesper", "Orion",
    "Solas", "Kairo", "Lyra", "Phaedra", "Apex", "Zenith", "Chronos", "Astral",
    "Nexus", "Flux", "Polaris", "Mira", "Hyperion", "Synapse", "Cascade", "Vortex"
]
