#!/usr/bin/env python3
"""
================================================================================
GEMINI CURSOR SWARM - UPDATER & APP MANAGER (update.py)
================================================================================
Features:
- Root command: 'gemswarm'
- Commands:
    gemswarm update [optional_zip_path]
    gemswarm uninstall [update_id | app]
    gemswarm status
    gemswarm run
- Unzips the newest .zip file in current directory (or specified path).
- Compares all files (SHA-256 hash & size) and copies ONLY new or edited files.
- Target directory:
    C:\\Users\\<USERNAME>\\AppData\\Local\\Programs\\Python\\Python314\\Gem-Cursor-Swarm\\
    (Creates folder if it doesn't exist).
- Works WITHOUT the terminal running as a window (GUI / native dialogs with pythonw).
- Tracks all updates in update_manifest.json to allow uninstalling specific updates
  or cleanly uninstalling the entire application.
================================================================================
"""

import os
import sys
import glob
import json
import time
import shutil
import hashlib
import zipfile
import subprocess
from datetime import datetime

# GUI fallback when running without terminal (pythonw.exe)
HAS_TKINTER = False
try:
    import tkinter as tk
    from tkinter import messagebox
    HAS_TKINTER = True
except Exception:
    HAS_TKINTER = False


def is_running_in_console():
    """Detects whether running in an interactive terminal or headless / pythonw."""
    try:
        return sys.stdout is not None and sys.stdout.isatty()
    except Exception:
        return False


def show_alert(title, message, is_error=False):
    """Displays message either in console or as a windowless GUI popup."""
    if is_running_in_console():
        prefix = "[ERROR] " if is_error else "[INFO] "
        print(f"\n{prefix}{title}\n{message}\n")
        return

    # Windows native message box (Zero console window requirement)
    if sys.platform.startswith("win"):
        try:
            import ctypes
            MB_ICONERROR = 0x10
            MB_ICONINFORMATION = 0x40
            icon = MB_ICONERROR if is_error else MB_ICONINFORMATION
            ctypes.windll.user32.MessageBoxW(0, str(message), str(title), icon | 0x0)
            return
        except Exception:
            pass

    # Tkinter dialog with hidden root window
    if HAS_TKINTER:
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            if is_error:
                messagebox.showerror(title, message, parent=root)
            else:
                messagebox.showinfo(title, message, parent=root)
            root.destroy()
            return
        except Exception:
            pass

    print(f"{title}: {message}")


def get_target_directory():
    """
    Returns the target destination directory:
    C:\\Users\\<USERNAME>\\AppData\\Local\\Programs\\Python\\Python314\\Gem-Cursor-Swarm\\
    Creates the folder first if it doesn't exist.
    """
    username = os.environ.get("USERNAME") or os.environ.get("USER") or "User"
    local_app_data = os.environ.get("LOCALAPPDATA")

    if local_app_data:
        target = os.path.join(local_app_data, "Programs", "Python", "Python314", "Gem-Cursor-Swarm")
    elif sys.platform.startswith("win"):
        target = f"C:\\Users\\{username}\\AppData\\Local\\Programs\\Python\\Python314\\Gem-Cursor-Swarm"
    else:
        # Cross-platform fallback for macOS/Linux
        target = os.path.expanduser(f"~/AppData/Local/Programs/Python/Python314/Gem-Cursor-Swarm")

    os.makedirs(target, exist_ok=True)
    return os.path.abspath(target)


def get_file_sha256(filepath):
    """Calculates SHA-256 hash of a file for exact content comparison."""
    if not os.path.exists(filepath) or os.path.isdir(filepath):
        return None
    sha = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            while chunk := f.read(65536):
                sha.update(chunk)
        return sha.hexdigest()
    except Exception:
        return None


def find_newest_zip(search_dir=None):
    """Finds the newest zip file in the current or specified directory."""
    dir_to_search = search_dir or os.getcwd()
    candidates = []

    # Check search_dir, script directory, and parent
    dirs_to_check = [
        dir_to_search,
        os.path.dirname(os.path.abspath(__file__)),
        os.path.abspath(".."),
    ]

    for d in dirs_to_check:
        if os.path.exists(d):
            candidates.extend(glob.glob(os.path.join(d, "*.zip")))

    candidates = list(set(candidates))
    if not candidates:
        return None

    # Sort by modified time descending
    candidates.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return candidates[0]


def get_manifest_path(target_dir):
    return os.path.join(target_dir, "update_manifest.json")


def load_manifest(target_dir):
    path = get_manifest_path(target_dir)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "app_name": "Gemini Cursor Swarm",
        "installed_path": target_dir,
        "created_at": datetime.now().isoformat(),
        "updates": [],
    }


def save_manifest(target_dir, manifest_data):
    path = get_manifest_path(target_dir)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(manifest_data, f, indent=2)
    except Exception as e:
        print(f"[Manifest] Error saving manifest: {e}")


def install_command_wrapper(target_dir):
    """
    Creates 'gemswarm.cmd' and 'gemswarm.bat' in the target directory and
    in Python Scripts / Local bin so 'gemswarm' can be used as a root command.
    """
    script_content = f"""@echo off
REM GemSwarm Root Command Wrapper
pythonw "{os.path.join(target_dir, 'update.py')}" %*
if errorlevel 1 (
    python "{os.path.join(target_dir, 'update.py')}" %*
)
"""
    cmd_file = os.path.join(target_dir, "gemswarm.cmd")
    bat_file = os.path.join(target_dir, "gemswarm.bat")
    try:
        with open(cmd_file, "w", encoding="utf-8") as f:
            f.write(script_content)
        with open(bat_file, "w", encoding="utf-8") as f:
            f.write(script_content)
    except Exception:
        pass

    # Also attempt to place in Python directory so it's directly in PATH
    python_dir = os.path.dirname(sys.executable)
    scripts_dir = os.path.join(python_dir, "Scripts")
    for place in [python_dir, scripts_dir]:
        if os.path.exists(place) and os.access(place, os.W_OK):
            try:
                with open(os.path.join(place, "gemswarm.cmd"), "w", encoding="utf-8") as f:
                    f.write(script_content)
                with open(os.path.join(place, "gemswarm.bat"), "w", encoding="utf-8") as f:
                    f.write(script_content)
            except Exception:
                pass


def perform_update(zip_path=None):
    """
    Unzips newest zip, compares ALL files, moves new/edited files to target directory,
    and records the update in the manifest.
    """
    target_dir = get_target_directory()
    resolved_zip = zip_path or find_newest_zip()

    if not resolved_zip or not os.path.exists(resolved_zip):
        show_alert(
            "Update Error",
            f"No update zip file found.\nPlace the update .zip in this folder and try again.",
            is_error=True
        )
        return False

    update_id = f"update_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    temp_extract = os.path.join(target_dir, f".temp_{update_id}")

    try:
        os.makedirs(temp_extract, exist_ok=True)

        with zipfile.ZipFile(resolved_zip, "r") as z:
            z.extractall(temp_extract)

        files_new = []
        files_edited = []
        files_unchanged = []

        manifest = load_manifest(target_dir)

        # Recursively inspect all files in the extracted archive
        for root_dir, _, files in os.walk(temp_extract):
            for file in files:
                src_path = os.path.join(root_dir, file)
                rel_path = os.path.relpath(src_path, temp_extract)

                # Skip internal temp/cache files
                if "__pycache__" in rel_path or rel_path.endswith(".pyc"):
                    continue

                dest_path = os.path.join(target_dir, rel_path)
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)

                src_hash = get_file_sha256(src_path)
                dest_hash = get_file_sha256(dest_path)

                if not os.path.exists(dest_path):
                    shutil.copy2(src_path, dest_path)
                    files_new.append(rel_path)
                elif src_hash != dest_hash:
                    shutil.copy2(src_path, dest_path)
                    files_edited.append(rel_path)
                else:
                    files_unchanged.append(rel_path)

        # Clean up temp folder
        shutil.rmtree(temp_extract, ignore_errors=True)

        # Ensure update.py itself is also copied to target directory
        self_path = os.path.abspath(__file__)
        dest_self = os.path.join(target_dir, "update.py")
        if self_path != dest_self:
            try:
                shutil.copy2(self_path, dest_self)
            except Exception:
                pass

        # Install gemswarm command wrapper
        install_command_wrapper(target_dir)

        # Record this update in the manifest
        update_entry = {
            "update_id": update_id,
            "zip_name": os.path.basename(resolved_zip),
            "timestamp": datetime.now().isoformat(),
            "files_new": files_new,
            "files_edited": files_edited,
            "files_unchanged": len(files_unchanged),
        }
        manifest["updates"].append(update_entry)
        save_manifest(target_dir, manifest)

        summary = (
            f"Update Completed Successfully!\n\n"
            f"Update ID: {update_id}\n"
            f"Zip: {os.path.basename(resolved_zip)}\n"
            f"Destination: {target_dir}\n\n"
            f"• New files moved: {len(files_new)}\n"
            f"• Edited files updated: {len(files_edited)}\n"
            f"• Unchanged files: {len(files_unchanged)}\n\n"
            f"Command 'gemswarm' is ready to use!"
        )
        show_alert("Gemini Cursor Swarm - Updated", summary)
        return True

    except Exception as e:
        shutil.rmtree(temp_extract, ignore_errors=True)
        show_alert("Update Failed", f"Error during update:\n{str(e)}", is_error=True)
        return False


def perform_uninstall(target_arg=None):
    """
    Uninstalls either:
    1. A specific update's files (if an update ID or zip name is provided).
    2. The entire application (if target_arg is 'app', 'all', or empty/prompted).
    """
    target_dir = get_target_directory()
    manifest = load_manifest(target_dir)

    if not manifest["updates"]:
        # If no updates tracked, ask to remove the directory
        if not target_arg or target_arg.lower() in ["app", "all", "full"]:
            shutil.rmtree(target_dir, ignore_errors=True)
            show_alert("Uninstalled", f"Gemini Cursor Swarm has been removed from:\n{target_dir}")
            return True

    # 1. Uninstalling a specific update
    if target_arg and target_arg.lower() not in ["app", "all", "full"]:
        matching_updates = [
            u for u in manifest["updates"]
            if u["update_id"] == target_arg or u["zip_name"] == target_arg or target_arg in u["update_id"]
        ]

        if not matching_updates:
            show_alert(
                "Uninstall Error",
                f"No update matching '{target_arg}' found.\nUse 'gemswarm status' to view installed update IDs.",
                is_error=True
            )
            return False

        update = matching_updates[-1]
        removed_count = 0
        for rel_file in update.get("files_new", []):
            fpath = os.path.join(target_dir, rel_file)
            if os.path.exists(fpath):
                try:
                    os.remove(fpath)
                    removed_count += 1
                except Exception:
                    pass

        manifest["updates"] = [u for u in manifest["updates"] if u["update_id"] != update["update_id"]]
        save_manifest(target_dir, manifest)

        show_alert(
            "Update Uninstalled",
            f"Reverted update: {update['update_id']}\nRemoved {removed_count} unique files associated with this update."
        )
        return True

    # 2. Complete app uninstall
    try:
        shutil.rmtree(target_dir, ignore_errors=True)
        show_alert(
            "Gemini Cursor Swarm Uninstalled",
            f"The entire Gemini Cursor Swarm application has been uninstalled.\nRemoved directory: {target_dir}"
        )
        return True
    except Exception as e:
        show_alert("Uninstall Error", f"Failed to uninstall:\n{str(e)}", is_error=True)
        return False


def show_status():
    """Displays installation status and update history."""
    target_dir = get_target_directory()
    manifest = load_manifest(target_dir)
    updates_count = len(manifest.get("updates", []))

    lines = [
        "Gemini Cursor Swarm - Installation Status",
        "=" * 50,
        f"Location: {target_dir}",
        f"Folder Exists: {'Yes' if os.path.exists(target_dir) else 'No'}",
        f"Total Updates Applied: {updates_count}",
        "",
        "Update History:",
    ]

    for u in manifest.get("updates", []):
        lines.append(f" • [{u.get('update_id')}] - {u.get('zip_name')} ({u.get('timestamp')[:19]})")
        lines.append(f"   Added: {len(u.get('files_new', []))}, Edited: {len(u.get('files_edited', []))}")

    if not manifest.get("updates"):
        lines.append("  (No updates registered yet)")

    msg = "\n".join(lines)
    show_alert("GemSwarm Status", msg)


def run_app():
    """Launches run.py from the installation directory."""
    target_dir = get_target_directory()
    run_py = os.path.join(target_dir, "run.py")

    if not os.path.exists(run_py):
        # Fallback to local run.py
        run_py = os.path.join(os.path.dirname(os.path.abspath(__file__)), "run.py")

    if not os.path.exists(run_py):
        show_alert("Error", "run.py not found in installation directory.", is_error=True)
        return

    # Run without terminal window
    python_exe = "pythonw" if sys.platform.startswith("win") else sys.executable
    try:
        subprocess.Popen([python_exe, run_py], cwd=os.path.dirname(run_py))
    except Exception:
        subprocess.Popen([sys.executable, run_py], cwd=os.path.dirname(run_py))


# ==============================================================================
# MAIN ROOT COMMAND DISPATCHER (gemswarm)
# ==============================================================================
def main():
    args = sys.argv[1:]

    # If called without arguments, perform default update or show status
    if not args:
        # Default behavior: unzip newest and update
        perform_update()
        return

    command = args[0].lower()

    if command == "update":
        zip_arg = args[1] if len(args) > 1 else None
        perform_update(zip_arg)

    elif command == "uninstall":
        target_arg = args[1] if len(args) > 1 else None
        perform_uninstall(target_arg)

    elif command == "status":
        show_status()

    elif command in ["run", "start"]:
        run_app()

    elif command in ["help", "--help", "-h"]:
        help_text = (
            "gemswarm commands:\n"
            "  gemswarm update [zip_file]   - Unzips and installs new/edited files\n"
            "  gemswarm uninstall [id|app]  - Uninstalls specific update or whole app\n"
            "  gemswarm status              - Shows installed files & update history\n"
            "  gemswarm run                 - Starts Gemini Cursor Swarm"
        )
        show_alert("GemSwarm Help", help_text)
    else:
        # Check if argument is a zip file directly
        if command.endswith(".zip") and os.path.exists(command):
            perform_update(command)
        else:
            show_alert("Unknown Command", f"Unknown command '{command}'.\nUse: update, uninstall, status, or run.", is_error=True)


if __name__ == "__main__":
    main()
