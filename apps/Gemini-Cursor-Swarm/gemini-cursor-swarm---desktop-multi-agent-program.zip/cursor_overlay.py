"""
Floating cursor overlay window:
- Window WITHOUT A TOP BAR and WITHOUT A BACKGROUND
- Looks like a hollow circle around a smaller filled circle (mouse cursor)
"""

import sys
import math
import random
import tkinter as tk


class FloatingCursorWindow:
    def __init__(self, master, agent_id, agent_data, get_settings_fn):
        self.master = master
        self.agent_id = agent_id
        self.agent_data = agent_data
        self.get_settings = get_settings_fn

        self.x = float(agent_data.get("x", random.randint(200, 600)))
        self.y = float(agent_data.get("y", random.randint(200, 500)))
        self.target_x = self.x
        self.target_y = self.y
        self.ripple_radius = 0
        self.is_destroyed = False

        self.win_size = 110
        self.center = self.win_size // 2

        self.top = tk.Toplevel(master)
        self.top.overrideredirect(True)       # NO TOP BAR / NO WINDOW BORDER
        self.top.wm_attributes("-topmost", True)

        # Platform transparent background setup
        self.trans_color = "#010101"
        if sys.platform.startswith("win"):
            self.top.wm_attributes("-transparentcolor", self.trans_color)
            self.top.config(bg=self.trans_color)
        elif sys.platform == "darwin":
            try:
                self.top.wm_attributes("-transparent", True)
                self.top.config(bg="systemTransparent")
            except Exception:
                self.top.wm_attributes("-alpha", 0.95)
                self.top.config(bg="#121212")
        else:
            try:
                self.top.wm_attributes("-alpha", 0.92)
            except Exception:
                pass
            self.top.config(bg="#18181b")

        self.canvas = tk.Canvas(
            self.top,
            width=self.win_size,
            height=self.win_size,
            bg=self.top["bg"],
            highlightthickness=0,
            bd=0
        )
        self.canvas.pack(fill="both", expand=True)

        self.update_geometry()
        self.draw_cursor()
        self.start_motion_loop()

    def update_geometry(self):
        if self.is_destroyed:
            return
        left = int(self.x - self.center)
        top = int(self.y - self.center)
        self.top.geometry(f"{self.win_size}x{self.win_size}+{left}+{top}")

    def draw_cursor(self):
        if self.is_destroyed:
            return
        self.canvas.delete("all")
        color = self.agent_data.get("color", "#06b6d4")
        name = self.agent_data.get("name", "Gemini")
        settings = self.get_settings()

        c = self.center
        outer_r = 24
        inner_r = 7

        # 1. Click Ripple effect
        if self.ripple_radius > 0 and settings.get("show_ripple_effects", True):
            self.canvas.create_oval(
                c - self.ripple_radius, c - self.ripple_radius,
                c + self.ripple_radius, c + self.ripple_radius,
                outline=color, width=2
            )

        # 2. Outer dark border glow
        self.canvas.create_oval(
            c - outer_r - 2, c - outer_r - 2,
            c + outer_r + 2, c + outer_r + 2,
            outline="#000000", width=4
        )

        # 3. Outer HOLLOW CIRCLE
        self.canvas.create_oval(
            c - outer_r, c - outer_r,
            c + outer_r, c + outer_r,
            outline=color, width=3
        )

        # 4. Inner FILLED CIRCLE (mouse cursor center)
        self.canvas.create_oval(
            c - inner_r, c - inner_r,
            c + inner_r, c + inner_r,
            fill=color, outline="#ffffff", width=1.5
        )

        # 5. Name tag badge
        if settings.get("show_name_badge", True):
            self.canvas.create_rectangle(
                c - 36, c + outer_r + 3,
                c + 36, c + outer_r + 19,
                fill="#0f172a", outline=color, width=1
            )
            self.canvas.create_text(
                c, c + outer_r + 11,
                text=name, fill="#f8fafc", font=("Helvetica", 8, "bold")
            )

    def trigger_click_effect(self):
        self.ripple_radius = 8
        def step():
            if self.is_destroyed:
                return
            self.ripple_radius += 4
            self.draw_cursor()
            if self.ripple_radius < 46:
                self.top.after(30, step)
            else:
                self.ripple_radius = 0
                self.draw_cursor()
        self.top.after(10, step)

    def move_to(self, tx, ty):
        sw = self.top.winfo_screenwidth()
        sh = self.top.winfo_screenheight()
        self.target_x = max(20, min(sw - 20, tx))
        self.target_y = max(20, min(sh - 20, ty))

    def start_motion_loop(self):
        def loop():
            if self.is_destroyed:
                return
            settings = self.get_settings()
            allow_moving = settings.get("allow_cursor_moving", True) and self.agent_data.get("allow_moving", True)

            if allow_moving and (abs(self.x - self.target_x) > 2 or abs(self.y - self.target_y) > 2):
                speed = settings.get("cursor_speed", 8)
                dx = self.target_x - self.x
                dy = self.target_y - self.y
                dist = math.hypot(dx, dy)
                if dist > 0:
                    step_val = min(dist, max(2, speed))
                    self.x += (dx / dist) * step_val
                    self.y += (dy / dist) * step_val
                    self.update_geometry()
                    self.agent_data["x"] = int(self.x)
                    self.agent_data["y"] = int(self.y)

            self.top.after(25, loop)
        loop()

    def destroy(self):
        self.is_destroyed = True
        try:
            self.top.destroy()
        except Exception:
            pass
