"""
Data persistence manager for Gemini Cursor Swarm (gemini_swarm_data.json).
"""

import os
import json
import time
from config import DATA_FILE, DEFAULT_MODEL, DEFAULT_REQUEST_COOLDOWN


class StorageManager:
    @staticmethod
    def load():
        default_data = {
            "api_key": os.environ.get("GEMINI_API_KEY", ""),
            "model_name": DEFAULT_MODEL,
            "global_settings": {
                "allow_cursor_moving": True,
                "allow_cursor_clicking": False,
                "mask_config_window": True,
                "cursor_speed": 8,
                "request_cooldown": DEFAULT_REQUEST_COOLDOWN,
                "show_name_badge": True,
                "show_ripple_effects": True,
                "wander_mode": False,
            },
            "agents": {},       # id -> agent dict
            "chats": {          # id -> chat dict
                "default": {
                    "id": "default",
                    "title": "General Chat",
                    "created_at": time.time(),
                    "messages": [],
                }
            },
            "active_chat_id": "default",
        }

        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)

                    # Auto-migrate deprecated or 503-prone models
                    if saved.get("model_name") in ["gemini-2.5-flash", "gemini-pro"]:
                        saved["model_name"] = DEFAULT_MODEL

                    # Ensure all default keys exist
                    for k, v in default_data.items():
                        if k not in saved:
                            saved[k] = v

                    if "global_settings" in saved:
                        for sk, sv in default_data["global_settings"].items():
                            if sk not in saved["global_settings"]:
                                saved["global_settings"][sk] = sv

                    return saved
            except Exception as e:
                print(f"[Storage] Error reading data file: {e}")

        return default_data

    @staticmethod
    def save(data):
        try:
            temp_file = DATA_FILE + ".tmp"
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(temp_file, DATA_FILE)
        except Exception as e:
            print(f"[Storage] Error saving data file: {e}")
