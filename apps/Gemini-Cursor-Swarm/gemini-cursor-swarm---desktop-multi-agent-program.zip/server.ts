import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const DATA_FILE = path.join(__dirname, 'gemini_swarm_data.json');

const PYTHON_FILES = [
  'run.py',
  'update.py',
  'config.py',
  'storage.py',
  'gemini_client.py',
  'cursor_overlay.py',
  'controller_window.py',
  'info.app.json',
  'requirements.txt',
  'gem-cursor-swarm.zip',
];

// File download endpoints
app.get('/api/download/:filename', (req, res) => {
  const file = req.params.filename;
  if (!PYTHON_FILES.includes(file)) {
    return res.status(404).send('File not found');
  }
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Disposition', `attachment; filename="${file}"`);
    res.setHeader('Content-Type', file.endsWith('.py') ? 'text/x-python' : 'text/plain');
    return res.sendFile(filePath);
  }
  res.status(404).send('File not found');
});

app.get('/api/run-py', (req, res) => {
  const filePath = path.join(__dirname, 'run.py');
  if (fs.existsSync(filePath)) {
    if (req.query.download === 'true') {
      res.setHeader('Content-Disposition', 'attachment; filename="run.py"');
      res.setHeader('Content-Type', 'text/x-python');
      return res.sendFile(filePath);
    }
    return res.json({ content: fs.readFileSync(filePath, 'utf-8') });
  }
  res.status(404).json({ error: 'run.py not found' });
});

app.get('/api/requirements', (req, res) => {
  const filePath = path.join(__dirname, 'requirements.txt');
  if (fs.existsSync(filePath)) {
    if (req.query.download === 'true') {
      res.setHeader('Content-Disposition', 'attachment; filename="requirements.txt"');
      res.setHeader('Content-Type', 'text/plain');
      return res.sendFile(filePath);
    }
    return res.json({ content: fs.readFileSync(filePath, 'utf-8') });
  }
  res.status(404).json({ error: 'requirements.txt not found' });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasApiKey: !!apiKey });
});

app.post('/api/validate-key', async (req, res) => {
  const userKey = req.body.apiKey || apiKey;
  if (!userKey) {
    return res.status(400).json({ error: 'No API key provided' });
  }

  try {
    const fetchRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${userKey}`
    );
    if (!fetchRes.ok) {
      const errBody = await fetchRes.text();
      return res.status(fetchRes.status).json({
        error: `Google API Error ${fetchRes.status}: ${errBody}`,
      });
    }

    const data = await fetchRes.json();
    const models = (data.models || [])
      .filter((m: any) =>
        (m.supportedGenerationMethods || []).includes('generateContent')
      )
      .map((m: any) => m.name.replace('models/', ''));

    const flash15 = models.filter((m: string) => m.includes('1.5-flash'));
    const otherFlash = models.filter((m: string) => m.includes('flash') && !m.includes('1.5-flash'));
    const rest = models.filter((m: string) => !m.includes('flash'));
    const sorted = [...flash15, ...otherFlash, ...rest];

    res.json({
      valid: true,
      models: sorted,
      recommended: sorted[0] || 'gemini-1.5-flash',
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to query models' });
  }
});

// Single-page Python Project Hub directly rendered from server without src/ or index.html
app.get('*', (req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gemini Cursor Swarm - Python Multi-Agent Desktop Program</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #030712;
      color: #f3f4f6;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.5;
      padding: 32px 20px;
    }
    .container { max-width: 900px; margin: 0 auto; }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 700;
      border-radius: 9999px;
      background: rgba(6, 182, 212, 0.15);
      color: #38bdf8;
      border: 1px solid rgba(6, 182, 212, 0.3);
      margin-bottom: 12px;
    }
    h1 { font-size: 24px; font-weight: 800; color: #ffffff; margin-bottom: 6px; }
    p.sub { font-size: 14px; color: #94a3b8; margin-bottom: 24px; }
    .card {
      background: #0f172a;
      border: 1px solid #1e293b;
      border-radius: 14px;
      padding: 20px;
      margin-bottom: 20px;
    }
    .card-title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #38bdf8;
      margin-bottom: 12px;
    }
    .fix-banner {
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
    }
    .fix-banner h3 { font-size: 14px; color: #34d399; margin-bottom: 4px; }
    .fix-banner p { font-size: 13px; color: #cbd5e1; }
    .cmd-box {
      background: #000000;
      border: 1px solid #1e293b;
      border-radius: 10px;
      padding: 14px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 13px;
      color: #34d399;
      user-select: all;
      margin: 10px 0;
    }
    .files-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 12px;
      margin-top: 10px;
    }
    .file-item {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 10px;
      padding: 12px 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      text-decoration: none;
      color: #f1f5f9;
      font-family: monospace;
      font-size: 12px;
      transition: all 0.15s ease;
    }
    .file-item:hover {
      background: #0284c7;
      color: #ffffff;
      border-color: #38bdf8;
    }
    .checklist {
      list-style: none;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }
    .checklist li {
      font-size: 12px;
      color: #cbd5e1;
      display: flex;
      align-items: flex-start;
      gap: 8px;
    }
    .checklist li span.chk { color: #34d399; font-weight: bold; }
    .btn-row { display: flex; gap: 10px; margin-top: 14px; }
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      background: #0284c7;
      color: #ffffff;
      text-decoration: none;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      transition: background 0.15s;
    }
    .btn:hover { background: #0369a1; }
    .btn-secondary {
      background: #334155;
      color: #f8fafc;
    }
    .btn-secondary:hover { background: #475569; }
  </style>
</head>
<body>
  <div class="container">
    <div class="badge">PYTHON MULTI-AGENT SYSTEM</div>
    <h1>Gemini Cursor Swarm (run.py)</h1>
    <p class="sub">Native multi-agent desktop application with frameless floating circle-in-circle cursor overlays, strictly isolated 2-tab main window, and rate-limited Gemini integration.</p>

    <div class="fix-banner">
      <div>
        <h3>✓ HTTP 503 ("High Demand") & Key Over-Request Issue Resolved</h3>
        <p>1. Added a <strong>Thread-Safe Rate Limiter</strong> with a customizable cooldown (default 2.0s) to prevent spamming the key.<br>
        2. Set primary model to <strong>gemini-1.5-flash</strong> (most stable capacity) with <strong>automatic failover</strong> across <code>gemini-2.0-flash</code>, <code>gemini-2.0-flash-lite</code>, and <code>gemini-flash-latest</code> whenever Google returns a 503 high-demand spike.<br>
        3. All <code>src/</code> and <code>index</code> files/folders removed per instruction. Structured cleanly into multiple Python files.</p>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Terminal & Updater Commands</div>
      <p style="font-size: 12px; color: #94a3b8;">Run this command in terminal to install/update directly:</p>
      <div class="cmd-box">pip install -r requirements.txt && python run.py</div>
      <p style="font-size: 12px; color: #94a3b8; margin-top: 8px;">Or use the headless updater tool:</p>
      <div class="cmd-box">python update.py update gem-cursor-swarm.zip</div>
      <div class="btn-row">
        <a class="btn" href="/api/download/gem-cursor-swarm.zip">⬇ Download gem-cursor-swarm.zip</a>
        <a class="btn btn-secondary" href="/api/download/update.py">⬇ Download update.py</a>
        <a class="btn btn-secondary" href="/api/download/run.py">⬇ Download run.py</a>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Python Architecture (Multiple Files)</div>
      <p style="font-size: 12px; color: #94a3b8;">Click any file to download directly:</p>
      <div class="files-grid">
        <a class="file-item" href="/api/download/run.py"><span>📄 run.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/update.py"><span>🔄 update.py (gemswarm)</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/config.py"><span>⚙️ config.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/gemini_client.py"><span>🤖 gemini_client.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/cursor_overlay.py"><span>🎯 cursor_overlay.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/controller_window.py"><span>🪟 controller_window.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/storage.py"><span>💾 storage.py</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/info.app.json"><span>📋 info.app.json</span><span>⬇</span></a>
        <a class="file-item" href="/api/download/gem-cursor-swarm.zip"><span>📦 gem-cursor-swarm.zip</span><span>⬇</span></a>
      </div>
    </div>

    <div class="card">
      <div class="card-title">All Requirements Built Into The Python Files</div>
      <ul class="checklist">
        <li><span class="chk">✓</span><span><strong>Window Without Top Bar/Background:</strong> Frameless circle-in-circle cursor overlay.</span></li>
        <li><span class="chk">✓</span><span><strong>Normal Window with TWO Tabs:</strong> Strictly 'Chat' and 'Settings'.</span></li>
        <li><span class="chk">✓</span><span><strong>Multiple Geminis:</strong> Independent concurrent AI cursor overlays.</span></li>
        <li><span class="chk">✓</span><span><strong>All Chat Data Saved:</strong> Automatic JSON persistence in gemini_swarm_data.json.</span></li>
        <li><span class="chk">✓</span><span><strong>Multiple Chats Allowed:</strong> Create, switch, and delete chat threads.</span></li>
        <li><span class="chk">✓</span><span><strong>Geminis CANNOT See Config Window:</strong> Coordinates blacked out from AI perception.</span></li>
        <li><span class="chk">✓</span><span><strong>Everything Can Be Turned On/Off:</strong> Moving, clicking, wander, speed, ripples, cooldown.</span></li>
        <li><span class="chk">✓</span><span><strong>Unique Names & Distinct Colors:</strong> Autonomous name selection without duplicates.</span></li>
        <li><span class="chk">✓</span><span><strong>No Preset Geminis & No Auto-Start:</strong> Starts with 0 active; new agents start paused.</span></li>
        <li><span class="chk">✓</span><span><strong>503 & 404 Protection:</strong> Request rate limiter + automated candidate model fallback.</span></li>
      </ul>
    </div>
  </div>
</body>
</html>`);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on http://0.0.0.0:${PORT}`);
});
