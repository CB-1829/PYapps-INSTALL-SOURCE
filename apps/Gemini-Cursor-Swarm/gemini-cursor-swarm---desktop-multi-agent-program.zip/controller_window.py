"""
Normal Controller Window for Gemini Cursor Swarm:
- Strictly TWO tabs: 'Chat' and 'Settings'
- Multi-chat manager (persisted)
- Agent controls, toggles, rate-limit cooldown, and model selection
"""

import time
import random
import threading
import tkinter as tk
from tkinter import ttk, messagebox

# Optional PyAutoGUI
try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.05
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False

from config import ACTIVE_MODELS, DEFAULT_MODEL, DISTINCT_COLORS, DEFAULT_REQUEST_COOLDOWN
from storage import StorageManager
from gemini_client import GeminiEngine
from cursor_overlay import FloatingCursorWindow


class GeminiSwarmApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gemini Cursor Swarm - Controller")
        self.root.geometry("880x660")
        self.root.minsize(740, 530)
        self.root.configure(bg="#090d16")

        # Load persisted data
        self.data = StorageManager.load()
        cooldown = self.data["global_settings"].get("request_cooldown", DEFAULT_REQUEST_COOLDOWN)
        self.engine = GeminiEngine(
            api_key=self.data.get("api_key", ""),
            model_name=self.data.get("model_name", DEFAULT_MODEL),
            cooldown=cooldown
        )

        # Active cursor overlay windows: agent_id -> FloatingCursorWindow
        # RULE: "they DO NOT START ON PROGRAM START" and "NO PRESET GEMINIS"
        self.cursor_windows = {}

        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self.configure_styles()

        self.create_header()

        # Notebook with strictly TWO TABS: Chat and Settings
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        self.chat_tab = ttk.Frame(self.notebook, style="Dark.TFrame")
        self.settings_tab = ttk.Frame(self.notebook, style="Dark.TFrame")

        self.notebook.add(self.chat_tab, text=" 💬 Chat & Swarm ")
        self.notebook.add(self.settings_tab, text=" ⚙️ Settings & Controls ")

        self.build_chat_ui()
        self.build_settings_ui()

        # Background wander worker
        self.running = True
        self.wander_thread = threading.Thread(target=self.wander_worker, daemon=True)
        self.wander_thread.start()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def configure_styles(self):
        bg = "#090d16"
        card_bg = "#0f172a"
        fg = "#f8fafc"
        self.style.configure("Dark.TFrame", background=bg)
        self.style.configure("Card.TFrame", background=card_bg, relief="flat")
        self.style.configure("TNotebook", background=bg, tabmargins=[2, 5, 2, 0])
        self.style.configure("TNotebook.Tab", background="#1e293b", foreground="#94a3b8", padding=[16, 7], font=("Helvetica", 10, "bold"))
        self.style.map("TNotebook.Tab",
            background=[("selected", "#0284c7"), ("active", "#334155")],
            foreground=[("selected", "#ffffff"), ("active", "#ffffff")]
        )
        self.style.configure("TLabel", background=bg, foreground=fg, font=("Helvetica", 9))
        self.style.configure("Card.TLabel", background=card_bg, foreground=fg, font=("Helvetica", 9))

    def create_header(self):
        header = tk.Frame(self.root, bg="#090d16", height=48)
        header.pack(fill="x", padx=14, pady=10)

        title_lbl = tk.Label(
            header,
            text="GEMINI CURSOR SWARM",
            font=("Helvetica", 13, "bold"),
            bg="#090d16",
            fg="#38bdf8"
        )
        title_lbl.pack(side="left")

        sub_lbl = tk.Label(
            header,
            text="• Multi-Agent Desktop Overlay System",
            font=("Helvetica", 9),
            bg="#090d16",
            fg="#64748b"
        )
        sub_lbl.pack(side="left", padx=8)

        # Top Spawn Button
        self.spawn_btn = tk.Button(
            header,
            text="+ Spawn New Gemini",
            command=self.spawn_new_gemini,
            bg="#0284c7",
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            relief="flat",
            font=("Helvetica", 9, "bold"),
            padx=14,
            pady=4,
            cursor="hand2"
        )
        self.spawn_btn.pack(side="right")

    # ==========================================================================
    # CHAT TAB UI (Multiple chats, all data saved)
    # ==========================================================================
    def build_chat_ui(self):
        pane = tk.PanedWindow(self.chat_tab, orient="horizontal", bg="#1e293b", bd=0, sashwidth=4)
        pane.pack(fill="both", expand=True, padx=6, pady=6)

        # Sidebar: Multiple Conversations
        left_col = tk.Frame(pane, bg="#0b1120", width=220)
        pane.add(left_col, minsize=180)

        chat_hdr = tk.Frame(left_col, bg="#0b1120")
        chat_hdr.pack(fill="x", padx=8, pady=8)

        tk.Label(chat_hdr, text="CONVERSATIONS", font=("Helvetica", 8, "bold"), bg="#0b1120", fg="#64748b").pack(side="left")

        new_chat_btn = tk.Button(
            chat_hdr, text="+ New", command=self.create_new_chat_thread,
            bg="#1e293b", fg="#38bdf8", relief="flat", font=("Helvetica", 8, "bold"),
            padx=6, pady=2, cursor="hand2"
        )
        new_chat_btn.pack(side="right")

        self.chat_listbox = tk.Listbox(
            left_col, bg="#0f172a", fg="#f1f5f9", selectbackground="#0284c7",
            selectforeground="#ffffff", bd=0, highlightthickness=0,
            font=("Helvetica", 9), activestyle="none"
        )
        self.chat_listbox.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.chat_listbox.bind("<<ListboxSelect>>", self.on_chat_selected)

        # Right Column: Active Chat
        right_col = tk.Frame(pane, bg="#090d16")
        pane.add(right_col, minsize=450)

        info_bar = tk.Frame(right_col, bg="#0f172a", height=38)
        info_bar.pack(fill="x", padx=6, pady=6)

        self.chat_title_label = tk.Label(
            info_bar, text="General Chat", font=("Helvetica", 10, "bold"),
            bg="#0f172a", fg="#f8fafc"
        )
        self.chat_title_label.pack(side="left", padx=10, pady=6)

        tk.Label(info_bar, text="Target:", bg="#0f172a", fg="#94a3b8", font=("Helvetica", 8)).pack(side="left", padx=(15, 4))
        self.target_agent_var = tk.StringVar(value="All Active Geminis")
        self.target_agent_combo = ttk.Combobox(
            info_bar, textvariable=self.target_agent_var,
            state="readonly", width=18
        )
        self.target_agent_combo.pack(side="left", pady=4)
        self.update_target_agent_combo()

        del_btn = tk.Button(
            info_bar, text="Delete Chat", command=self.delete_current_chat,
            bg="#334155", fg="#f87171", relief="flat", font=("Helvetica", 8),
            padx=8, pady=2, cursor="hand2"
        )
        del_btn.pack(side="right", padx=8)

        self.chat_display = tk.Text(
            right_col, bg="#030712", fg="#f3f4f6", wrap="word",
            font=("Helvetica", 9), bd=0, padx=10, pady=10,
            highlightthickness=0
        )
        self.chat_display.pack(fill="both", expand=True, padx=6, pady=(0, 6))

        self.chat_display.tag_config("user", foreground="#38bdf8", font=("Helvetica", 9, "bold"))
        self.chat_display.tag_config("system", foreground="#94a3b8", font=("Helvetica", 8, "italic"))
        self.chat_display.tag_config("text", foreground="#f3f4f6", font=("Helvetica", 9))

        input_bar = tk.Frame(right_col, bg="#0f172a")
        input_bar.pack(fill="x", padx=6, pady=(0, 6))

        self.msg_entry = tk.Entry(
            input_bar, bg="#1e293b", fg="#ffffff", insertbackground="#38bdf8",
            font=("Helvetica", 10), bd=0, relief="flat"
        )
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=8, pady=8, ipady=4)
        self.msg_entry.bind("<Return>", lambda e: self.send_chat_message())

        send_btn = tk.Button(
            input_bar, text="Send", command=self.send_chat_message,
            bg="#0284c7", fg="#ffffff", font=("Helvetica", 9, "bold"),
            relief="flat", padx=16, pady=6, cursor="hand2"
        )
        send_btn.pack(side="right", padx=(0, 8), pady=8)

        self.refresh_chat_listbox()
        self.load_active_chat_messages()

    # ==========================================================================
    # SETTINGS TAB UI (Everything turned on/off, agent management, API key, rate limit)
    # ==========================================================================
    def build_settings_ui(self):
        container = tk.Frame(self.settings_tab, bg="#090d16")
        container.pack(fill="both", expand=True, padx=8, pady=8)

        canvas = tk.Canvas(container, bg="#090d16", bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable = tk.Frame(canvas, bg="#090d16")

        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # --- SECTION 1: GLOBAL TOGGLES & SPEED ---
        sec1 = tk.LabelFrame(scrollable, text=" GLOBAL CURSOR & BEHAVIOR CONTROLS ", bg="#0f172a", fg="#38bdf8", font=("Helvetica", 9, "bold"), padx=12, pady=10)
        sec1.pack(fill="x", padx=4, pady=6)

        self.glob_move_var = tk.BooleanVar(value=self.data["global_settings"].get("allow_cursor_moving", True))
        tk.Checkbutton(
            sec1, text="Allow Cursor Moving (Global)", variable=self.glob_move_var,
            bg="#0f172a", fg="#f8fafc", selectcolor="#1e293b", activebackground="#0f172a",
            command=self.save_settings_state
        ).pack(anchor="w", pady=2)

        self.glob_click_var = tk.BooleanVar(value=self.data["global_settings"].get("allow_cursor_clicking", False))
        tk.Checkbutton(
            sec1, text="Allow Cursor Clicking (Global)", variable=self.glob_click_var,
            bg="#0f172a", fg="#f8fafc", selectcolor="#1e293b", activebackground="#0f172a",
            command=self.save_settings_state
        ).pack(anchor="w", pady=2)

        self.glob_badge_var = tk.BooleanVar(value=self.data["global_settings"].get("show_name_badge", True))
        tk.Checkbutton(
            sec1, text="Show Agent Name Badge Below Circle Cursor", variable=self.glob_badge_var,
            bg="#0f172a", fg="#f8fafc", selectcolor="#1e293b", activebackground="#0f172a",
            command=self.on_appearance_toggle
        ).pack(anchor="w", pady=2)

        self.glob_ripple_var = tk.BooleanVar(value=self.data["global_settings"].get("show_ripple_effects", True))
        tk.Checkbutton(
            sec1, text="Show Expanding Ripple Effect on Cursor Clicks", variable=self.glob_ripple_var,
            bg="#0f172a", fg="#f8fafc", selectcolor="#1e293b", activebackground="#0f172a",
            command=self.save_settings_state
        ).pack(anchor="w", pady=2)

        self.glob_wander_var = tk.BooleanVar(value=self.data["global_settings"].get("wander_mode", False))
        tk.Checkbutton(
            sec1, text="Autonomous Wandering Mode (Active Geminis explore desktop)", variable=self.glob_wander_var,
            bg="#0f172a", fg="#f8fafc", selectcolor="#1e293b", activebackground="#0f172a",
            command=self.save_settings_state
        ).pack(anchor="w", pady=2)

        # Movement Speed Slider
        speed_frame = tk.Frame(sec1, bg="#0f172a")
        speed_frame.pack(fill="x", pady=4)
        tk.Label(speed_frame, text="Movement Speed:", bg="#0f172a", fg="#cbd5e1").pack(side="left")
        self.speed_scale = tk.Scale(
            speed_frame, from_=2, to=24, orient="horizontal", bg="#0f172a", fg="#38bdf8",
            troughcolor="#1e293b", highlightthickness=0, command=lambda v: self.save_settings_state()
        )
        self.speed_scale.set(self.data["global_settings"].get("cursor_speed", 8))
        self.speed_scale.pack(side="left", padx=10, fill="x", expand=True)

        # --- SECTION 2: RATE LIMITING & ANTI-FLOOD CONTROLS (503/429 PROTECTION) ---
        sec2 = tk.LabelFrame(scrollable, text=" RATE LIMITING & ANTI-FLOOD (PREVENTS 503 & 429 ERRORS) ", bg="#0f172a", fg="#fbbf24", font=("Helvetica", 9, "bold"), padx=12, pady=10)
        sec2.pack(fill="x", padx=4, pady=6)

        tk.Label(
            sec2,
            text="Controls the minimum cooldown between consecutive API requests. Prevents 'requesting too much from the key'\n"
                 "and stops Google's 'HTTP Error 503: High Demand / Unavailable' server rejections.",
            bg="#0f172a", fg="#94a3b8", justify="left", font=("Helvetica", 8)
        ).pack(anchor="w", pady=(0, 6))

        cooldown_frame = tk.Frame(sec2, bg="#0f172a")
        cooldown_frame.pack(fill="x", pady=2)
        tk.Label(cooldown_frame, text="Request Cooldown (seconds):", bg="#0f172a", fg="#cbd5e1").pack(side="left")
        self.cooldown_scale = tk.Scale(
            cooldown_frame, from_=0.5, to=6.0, resolution=0.5, orient="horizontal", bg="#0f172a", fg="#fbbf24",
            troughcolor="#1e293b", highlightthickness=0, command=lambda v: self.save_cooldown_state()
        )
        self.cooldown_scale.set(self.data["global_settings"].get("request_cooldown", DEFAULT_REQUEST_COOLDOWN))
        self.cooldown_scale.pack(side="left", padx=10, fill="x", expand=True)

        # --- SECTION 3: VISION REDACTION SHIELD ---
        sec3 = tk.LabelFrame(scrollable, text=" VISION PRIVACY SHIELD ", bg="#0f172a", fg="#10b981", font=("Helvetica", 9, "bold"), padx=12, pady=10)
        sec3.pack(fill="x", padx=4, pady=6)

        shield_lbl = tk.Label(
            sec3,
            text="✓ STRICT MASKING ENFORCED: The bounding box of this Config/Chat window is automatically\n"
                 "redacted and blacked out before any screenshot is sent to Gemini AI.\n"
                 "Geminis CANNOT see, inspect, or interact with this window.",
            bg="#0f172a", fg="#34d399", justify="left", font=("Helvetica", 8)
        )
        shield_lbl.pack(anchor="w", pady=2)

        # --- SECTION 4: GEMINI AGENTS MANAGEMENT ---
        sec4 = tk.LabelFrame(scrollable, text=" REGISTERED GEMINI AGENTS ", bg="#0f172a", fg="#38bdf8", font=("Helvetica", 9, "bold"), padx=12, pady=10)
        sec4.pack(fill="x", padx=4, pady=6)

        tk.Label(
            sec4,
            text="Rule: No preset Geminis. Newly spawned Geminis DO NOT start automatically.\n"
                 "Toggle each Gemini cursor on or off below:",
            bg="#0f172a", fg="#94a3b8", justify="left", font=("Helvetica", 8)
        ).pack(anchor="w", pady=(0, 8))

        self.agents_container = tk.Frame(sec4, bg="#0f172a")
        self.agents_container.pack(fill="x")
        self.refresh_agents_list_ui()

        # --- SECTION 5: API KEY & WORKING MODEL AUTO-DETECTOR ---
        sec5 = tk.LabelFrame(scrollable, text=" GEMINI API & MODEL CONFIGURATION ", bg="#0f172a", fg="#cbd5e1", font=("Helvetica", 9, "bold"), padx=12, pady=10)
        sec5.pack(fill="x", padx=4, pady=6)

        api_row = tk.Frame(sec5, bg="#0f172a")
        api_row.pack(fill="x", pady=4)
        tk.Label(api_row, text="Gemini API Key:", bg="#0f172a", fg="#cbd5e1", width=14, anchor="w").pack(side="left")
        self.api_key_entry = tk.Entry(api_row, bg="#1e293b", fg="#ffffff", show="•", bd=0)
        self.api_key_entry.insert(0, self.data.get("api_key", ""))
        self.api_key_entry.pack(side="left", fill="x", expand=True, padx=6)

        save_key_btn = tk.Button(
            api_row, text="Save Key", command=self.save_api_key,
            bg="#1e293b", fg="#38bdf8", relief="flat", padx=8, pady=2, cursor="hand2"
        )
        save_key_btn.pack(side="left")

        # Auto-detect Models button
        detect_btn = tk.Button(
            api_row, text="⚡ Auto-Detect Models", command=self.auto_detect_models,
            bg="#0284c7", fg="#ffffff", relief="flat", padx=8, pady=2, cursor="hand2", font=("Helvetica", 8, "bold")
        )
        detect_btn.pack(side="left", padx=(4, 0))

        model_row = tk.Frame(sec5, bg="#0f172a")
        model_row.pack(fill="x", pady=4)
        tk.Label(model_row, text="Model:", bg="#0f172a", fg="#cbd5e1", width=14, anchor="w").pack(side="left")

        current_model = self.data.get("model_name", DEFAULT_MODEL)
        if current_model not in ACTIVE_MODELS:
            current_model = DEFAULT_MODEL

        self.model_combo = ttk.Combobox(model_row, values=ACTIVE_MODELS, width=24, state="readonly")
        self.model_combo.set(current_model)
        self.model_combo.pack(side="left", padx=6)
        self.model_combo.bind("<<ComboboxSelected>>", lambda e: self.save_model_choice())

        self.status_feedback_lbl = tk.Label(
            sec5,
            text=f"Active Model: {current_model} • Auto-failover enabled to bypass 503 high-demand spikes",
            bg="#0f172a", fg="#94a3b8", font=("Helvetica", 8)
        )
        self.status_feedback_lbl.pack(anchor="w", pady=(4, 0))

    def save_cooldown_state(self):
        val = float(self.cooldown_scale.get())
        self.data["global_settings"]["request_cooldown"] = val
        self.engine.set_cooldown(val)
        StorageManager.save(self.data)

    def auto_detect_models(self):
        """Discovers available models for user's key and automatically selects a working one."""
        self.save_api_key()
        self.status_feedback_lbl.config(text="Connecting to Google API to discover models...", fg="#38bdf8")
        self.root.update_idletasks()

        def worker():
            models, err = self.engine.discover_models()
            def update_ui():
                if err:
                    self.status_feedback_lbl.config(text=f"⚠️ {err}", fg="#f87171")
                else:
                    self.model_combo["values"] = models
                    if models:
                        best = models[0]
                        self.model_combo.set(best)
                        self.data["model_name"] = best
                        self.engine.model_name = best
                        StorageManager.save(self.data)
                        self.status_feedback_lbl.config(
                            text=f"✓ Connected! Found {len(models)} working models. Active: {best}",
                            fg="#34d399"
                        )
            self.root.after(0, update_ui)

        threading.Thread(target=worker, daemon=True).start()

    def refresh_agents_list_ui(self):
        for w in self.agents_container.winfo_children():
            w.destroy()

        agents = self.data.get("agents", {})
        if not agents:
            lbl = tk.Label(
                self.agents_container,
                text="No Geminis spawned yet. Click '+ Spawn New Gemini' above!",
                bg="#0f172a", fg="#64748b", font=("Helvetica", 9, "italic")
            )
            lbl.pack(pady=8)
            return

        for agent_id, agent in agents.items():
            card = tk.Frame(self.agents_container, bg="#1e293b", padx=8, pady=6)
            card.pack(fill="x", pady=4)

            color = agent.get("color", "#06b6d4")
            color_box = tk.Canvas(card, width=18, height=18, bg="#1e293b", highlightthickness=0)
            color_box.create_oval(2, 2, 16, 16, fill=color, outline="#ffffff")
            color_box.pack(side="left", padx=(0, 8))

            name = agent.get("name", "Gemini")
            tk.Label(card, text=name, bg="#1e293b", fg="#ffffff", font=("Helvetica", 10, "bold")).pack(side="left")

            is_active = agent_id in self.cursor_windows
            status_text = "● RUNNING" if is_active else "○ STOPPED"
            status_fg = "#10b981" if is_active else "#64748b"
            tk.Label(card, text=status_text, bg="#1e293b", fg=status_fg, font=("Helvetica", 8, "bold")).pack(side="left", padx=12)

            # Delete button
            tk.Button(
                card, text="✕ Delete", command=lambda aid=agent_id: self.delete_agent(aid),
                bg="#334155", fg="#f87171", relief="flat", font=("Helvetica", 8),
                padx=6, pady=2, cursor="hand2"
            ).pack(side="right", padx=4)

            # Start/Stop Cursor overlay window
            toggle_text = "Stop Cursor" if is_active else "Start Cursor"
            toggle_bg = "#dc2626" if is_active else "#059669"
            tk.Button(
                card, text=toggle_text, command=lambda aid=agent_id: self.toggle_agent_active(aid),
                bg=toggle_bg, fg="#ffffff", relief="flat", font=("Helvetica", 8, "bold"),
                padx=10, pady=2, cursor="hand2"
            ).pack(side="right", padx=4)

            # Per-agent move checkbox
            mv_var = tk.BooleanVar(value=agent.get("allow_moving", True))
            def on_mv(aid=agent_id, v=mv_var):
                self.data["agents"][aid]["allow_moving"] = v.get()
                StorageManager.save(self.data)
            tk.Checkbutton(
                card, text="Move", variable=mv_var, command=on_mv,
                bg="#1e293b", fg="#cbd5e1", selectcolor="#0f172a", activebackground="#1e293b", font=("Helvetica", 8)
            ).pack(side="right", padx=4)

            # Per-agent click checkbox
            ck_var = tk.BooleanVar(value=agent.get("allow_clicking", False))
            def on_ck(aid=agent_id, v=ck_var):
                self.data["agents"][aid]["allow_clicking"] = v.get()
                StorageManager.save(self.data)
            tk.Checkbutton(
                card, text="Click", variable=ck_var, command=on_ck,
                bg="#1e293b", fg="#cbd5e1", selectcolor="#0f172a", activebackground="#1e293b", font=("Helvetica", 8)
            ).pack(side="right", padx=4)

    # ==========================================================================
    # AGENT SPAWN & ACTIVATION LOGIC
    # ==========================================================================
    def spawn_new_gemini(self):
        existing_names = [a.get("name") for a in self.data["agents"].values() if a.get("name")]
        used_colors = [a.get("color") for a in self.data["agents"].values()]
        avail_colors = [c for c in DISTINCT_COLORS if c not in used_colors]
        color = avail_colors[0] if avail_colors else random.choice(DISTINCT_COLORS)

        self.spawn_btn.config(state="disabled", text="Choosing Name...")

        def worker():
            name = self.engine.choose_unique_name(existing_names)
            agent_id = f"agent_{int(time.time() * 1000)}"
            new_agent = {
                "id": agent_id,
                "name": name,
                "color": color,
                "allow_moving": True,
                "allow_clicking": False,
                "x": random.randint(150, max(200, self.root.winfo_screenwidth() - 200)),
                "y": random.randint(150, max(200, self.root.winfo_screenheight() - 200)),
                "created_at": time.time(),
            }
            self.data["agents"][agent_id] = new_agent
            StorageManager.save(self.data)

            def on_done():
                self.spawn_btn.config(state="normal", text="+ Spawn New Gemini")
                self.refresh_agents_list_ui()
                self.update_target_agent_combo()
                self.append_system_msg(
                    f"✨ Gemini chose unique name '{name}' (color {color}). "
                    f"Per instructions, it is currently paused. Click 'Start Cursor' in Settings to display its floating circular window."
                )
            self.root.after(0, on_done)

        threading.Thread(target=worker, daemon=True).start()

    def toggle_agent_active(self, agent_id):
        if agent_id in self.cursor_windows:
            self.cursor_windows[agent_id].destroy()
            del self.cursor_windows[agent_id]
            self.append_system_msg(f"🛑 Gemini cursor for '{self.data['agents'][agent_id]['name']}' stopped.")
        else:
            agent_data = self.data["agents"].get(agent_id)
            if agent_data:
                win = FloatingCursorWindow(
                    self.root,
                    agent_id,
                    agent_data,
                    lambda: self.data["global_settings"]
                )
                self.cursor_windows[agent_id] = win
                self.append_system_msg(f"🚀 Floating circle cursor for '{agent_data['name']}' is ACTIVE on desktop!")

        self.refresh_agents_list_ui()

    def delete_agent(self, agent_id):
        if agent_id in self.cursor_windows:
            self.cursor_windows[agent_id].destroy()
            del self.cursor_windows[agent_id]
        if agent_id in self.data["agents"]:
            name = self.data["agents"][agent_id]["name"]
            del self.data["agents"][agent_id]
            StorageManager.save(self.data)
            self.append_system_msg(f"🗑️ Gemini '{name}' was deleted.")
        self.refresh_agents_list_ui()
        self.update_target_agent_combo()

    # ==========================================================================
    # CHAT THREADS & MESSAGING LOGIC (WITH SEQUENTIAL DISPATCH TO AVOID 503)
    # ==========================================================================
    def create_new_chat_thread(self):
        num = len(self.data["chats"]) + 1
        cid = f"chat_{int(time.time() * 1000)}"
        self.data["chats"][cid] = {
            "id": cid,
            "title": f"Chat {num}",
            "created_at": time.time(),
            "messages": [],
        }
        self.data["active_chat_id"] = cid
        StorageManager.save(self.data)
        self.refresh_chat_listbox()
        self.load_active_chat_messages()

    def delete_current_chat(self):
        active_id = self.data.get("active_chat_id")
        if not active_id or len(self.data["chats"]) <= 1:
            messagebox.showwarning("Notice", "Cannot delete the only remaining chat thread.")
            return

        del self.data["chats"][active_id]
        self.data["active_chat_id"] = list(self.data["chats"].keys())[0]
        StorageManager.save(self.data)
        self.refresh_chat_listbox()
        self.load_active_chat_messages()

    def refresh_chat_listbox(self):
        self.chat_listbox.delete(0, "end")
        active_id = self.data.get("active_chat_id")
        sel_idx = 0
        for i, (cid, chat) in enumerate(self.data["chats"].items()):
            self.chat_listbox.insert("end", f"💬 {chat.get('title', 'Untitled')}")
            if cid == active_id:
                sel_idx = i
        if self.data["chats"]:
            self.chat_listbox.select_set(sel_idx)

    def on_chat_selected(self, event):
        sel = self.chat_listbox.curselection()
        if sel:
            idx = sel[0]
            cid = list(self.data["chats"].keys())[idx]
            self.data["active_chat_id"] = cid
            StorageManager.save(self.data)
            self.load_active_chat_messages()

    def load_active_chat_messages(self):
        active_id = self.data.get("active_chat_id")
        chat = self.data["chats"].get(active_id)
        if not chat:
            return

        self.chat_title_label.config(text=chat.get("title", "Chat"))
        self.chat_display.config(state="normal")
        self.chat_display.delete("1.0", "end")

        for msg in chat.get("messages", []):
            role = msg.get("role")
            sender = msg.get("sender", "Gemini")
            text = msg.get("text", "")
            t_str = time.strftime("%H:%M", time.localtime(msg.get("timestamp", time.time())))

            if role == "user":
                self.chat_display.insert("end", f"[{t_str}] You: ", "user")
                self.chat_display.insert("end", f"{text}\n\n", "text")
            elif role == "system":
                self.chat_display.insert("end", f"[{t_str}] ℹ️ {text}\n\n", "system")
            else:
                tag = f"ag_{sender}"
                color = msg.get("color", "#a855f7")
                self.chat_display.tag_config(tag, foreground=color, font=("Helvetica", 9, "bold"))
                self.chat_display.insert("end", f"[{t_str}] {sender}: ", tag)
                self.chat_display.insert("end", f"{text}\n\n", "text")

        self.chat_display.see("end")
        self.chat_display.config(state="disabled")

    def append_system_msg(self, text):
        active_id = self.data.get("active_chat_id")
        if not active_id or active_id not in self.data["chats"]:
            return
        self.data["chats"][active_id]["messages"].append({
            "role": "system",
            "text": text,
            "timestamp": time.time()
        })
        StorageManager.save(self.data)
        self.load_active_chat_messages()

    def update_target_agent_combo(self):
        agents = [a["name"] for a in self.data["agents"].values() if a.get("name")]
        values = ["All Active Geminis"] + agents
        self.target_agent_combo["values"] = values
        if self.target_agent_var.get() not in values:
            self.target_agent_var.set("All Active Geminis")

    def send_chat_message(self):
        text = self.msg_entry.get().strip()
        if not text:
            return
        self.msg_entry.delete(0, "end")

        active_id = self.data.get("active_chat_id")
        if not active_id:
            return

        self.data["chats"][active_id]["messages"].append({
            "role": "user",
            "text": text,
            "timestamp": time.time()
        })
        StorageManager.save(self.data)
        self.load_active_chat_messages()

        target = self.target_agent_var.get()
        recipients = []
        all_agents = list(self.data.get("agents", {}).values())

        if not all_agents:
            self.append_system_msg("⚠️ No Geminis exist yet. Click '+ Spawn New Gemini' to create one!")
            return

        if target == "All Active Geminis":
            # If any are actively floating on desktop, target those; otherwise target all spawned agents
            active_from_windows = [
                self.data["agents"][aid]
                for aid in self.cursor_windows.keys()
                if aid in self.data["agents"]
            ]
            recipients = active_from_windows if active_from_windows else all_agents
        else:
            # Target specific agent by name whether its cursor overlay is active or paused
            matched = [a for a in all_agents if a.get("name") == target]
            recipients = matched if matched else all_agents

        if not recipients:
            self.append_system_msg(f"⚠️ Could not find Gemini '{target}'.")
            return

        # Sequential worker to process responses one-by-one with rate-limit cooldown
        def dispatch_worker():
            try:
                for agent_data in recipients:
                    self.generate_agent_reply(agent_data, text, active_id)
            except Exception as e:
                err_text = f"❌ Dispatch error: {str(e)}"
                print(err_text)
                self.root.after(0, lambda: self.append_system_msg(err_text))

        threading.Thread(target=dispatch_worker, daemon=True).start()

    def generate_agent_reply(self, agent_data, user_prompt, chat_id):
        name = agent_data.get("name", "Gemini")
        color = agent_data.get("color", "#a855f7")
        aid = agent_data.get("id", "")

        # Safe coordinates of config window to MASK IT
        try:
            x = self.root.winfo_rootx()
            y = self.root.winfo_rooty()
            w = self.root.winfo_width()
            h = self.root.winfo_height()
        except Exception:
            x, y, w, h = 0, 0, 100, 100

        # Visual feedback: trigger cursor ripple and move towards target if allowed
        win = self.cursor_windows.get(aid)
        if win and not win.is_destroyed:
            try:
                self.root.after(0, win.trigger_click_effect)
                if self.data["global_settings"].get("allow_cursor_moving", True) and agent_data.get("allow_moving", True):
                    sw = self.root.winfo_screenwidth()
                    sh = self.root.winfo_screenheight()
                    tx = random.randint(40, sw - 40)
                    ty = random.randint(40, sh - 40)
                    if x <= tx <= x + w and y <= ty <= y + h:
                        tx = (tx + w + 120) % sw
                    self.root.after(0, lambda: win.move_to(tx, ty))
            except Exception as e:
                print(f"[Visual Effect] {e}")

        # Show thinking indicator in UI so the user knows Gemini received the request
        self.root.after(0, lambda: self.append_system_msg(f"⏳ {name} is thinking..."))

        sys_inst = (
            f"You are '{name}', an autonomous Gemini AI cursor on the user's desktop. "
            f"Your cursor visually appears as a distinctive hollow circle around a smaller filled circle. "
            f"PRIVACY CONSTRAINT: You CANNOT and MUST NOT see the config or chat control window. That window is strictly redacted. "
            f"Reply helpfully and concisely to the user."
        )

        try:
            reply, err = self.engine.call_gemini_raw(user_prompt, sys_inst)

            # Update saved model name if auto-fallback switched models
            if self.engine.model_name != self.data.get("model_name"):
                self.data["model_name"] = self.engine.model_name
                self.root.after(0, lambda: self.model_combo.set(self.engine.model_name))
                StorageManager.save(self.data)

            # Format error visibly if response failed
            if not reply:
                reply = f"⚠️ [{name}]: Failed to get response from Gemini.\nDetails: {err or 'Unknown error. Check API Key in Settings.'}"
                self.root.after(0, lambda: self.status_feedback_lbl.config(
                    text=f"⚠️ {name}: {err[:80] if err else 'Error'}", fg="#f87171"
                ))

            self.data["chats"][chat_id]["messages"].append({
                "role": "model",
                "sender": name,
                "color": color,
                "text": reply,
                "timestamp": time.time()
            })
            StorageManager.save(self.data)

            # Trigger desktop click if allowed
            if self.data["global_settings"].get("allow_cursor_clicking", False) and agent_data.get("allow_clicking", False):
                if PYAUTOGUI_AVAILABLE and win and not win.is_destroyed:
                    try:
                        pyautogui.click(int(win.x), int(win.y))
                    except Exception as e:
                        print(f"[PyAutoGUI] Click error: {e}")

        except Exception as e:
            err_msg = f"❌ Exception communicating with {name}: {str(e)}"
            print(err_msg)
            self.data["chats"][chat_id]["messages"].append({
                "role": "system",
                "text": err_msg,
                "timestamp": time.time()
            })
            StorageManager.save(self.data)

        self.root.after(0, self.load_active_chat_messages)

    # ==========================================================================
    # AUTONOMOUS WANDER WORKER
    # ==========================================================================
    def wander_worker(self):
        while self.running:
            time.sleep(3.5)
            if not self.running:
                break
            if not self.data["global_settings"].get("wander_mode", False) or not self.cursor_windows:
                continue

            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            cx = self.root.winfo_rootx()
            cy = self.root.winfo_rooty()
            cw = self.root.winfo_width()
            ch = self.root.winfo_height()

            for aid, win in list(self.cursor_windows.items()):
                agent = self.data["agents"].get(aid)
                if not agent or not agent.get("allow_moving", True):
                    continue

                nx = random.randint(40, sw - 40)
                ny = random.randint(40, sh - 40)
                if cx <= nx <= cx + cw and cy <= ny <= cy + ch:
                    nx = (nx + cw + 60) % sw

                self.root.after(0, lambda w=win, x=nx, y=ny: w.move_to(x, y))

    # ==========================================================================
    # SETTINGS HANDLERS
    # ==========================================================================
    def save_settings_state(self):
        self.data["global_settings"]["allow_cursor_moving"] = self.glob_move_var.get()
        self.data["global_settings"]["allow_cursor_clicking"] = self.glob_click_var.get()
        self.data["global_settings"]["show_name_badge"] = self.glob_badge_var.get()
        self.data["global_settings"]["show_ripple_effects"] = self.glob_ripple_var.get()
        self.data["global_settings"]["wander_mode"] = self.glob_wander_var.get()
        self.data["global_settings"]["cursor_speed"] = self.speed_scale.get()
        StorageManager.save(self.data)

    def on_appearance_toggle(self):
        self.save_settings_state()
        for win in self.cursor_windows.values():
            win.draw_cursor()

    def save_api_key(self):
        key = self.api_key_entry.get().strip()
        self.data["api_key"] = key
        self.engine.api_key = key
        StorageManager.save(self.data)
        self.status_feedback_lbl.config(text="API key saved.", fg="#34d399")

    def save_model_choice(self):
        m = self.model_combo.get()
        self.data["model_name"] = m
        self.engine.model_name = m
        StorageManager.save(self.data)
        self.status_feedback_lbl.config(text=f"Active Model updated to: {m}", fg="#38bdf8")

    def on_close(self):
        self.running = False
        for win in list(self.cursor_windows.values()):
            win.destroy()
        self.root.destroy()
